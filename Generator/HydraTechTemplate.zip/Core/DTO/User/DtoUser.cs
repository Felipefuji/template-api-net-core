﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO.User
{
    public class DtoUser
    {
        public string Email { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }
    }
}
