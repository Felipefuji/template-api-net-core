﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.$safeprojectname$.AuthContext.Models
{
    public class Role : IdentityRole<Guid>
    { }
}
